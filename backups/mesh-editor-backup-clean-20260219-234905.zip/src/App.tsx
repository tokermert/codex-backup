import { useEffect, useMemo, useRef, useState } from 'react'
import MeshCanvas from './components/MeshCanvas'
import RightPanel from './components/RightPanel'
import Toolbar from './components/Toolbar'
import { store } from './mesh/store'

export default function App() {
  const [, setTick] = useState(0)
  const viewportRef = useRef<HTMLDivElement>(null)
  const [viewportSize, setViewportSize] = useState({ width: 0, height: 0 })

  useEffect(() => {
    const unsub = store.subscribe(() => setTick(n => n + 1))
    return () => unsub()
  }, [])

  useEffect(() => {
    const el = viewportRef.current
    if (!el) return

    const ro = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect
      setViewportSize({ width: Math.max(0, width), height: Math.max(0, height) })
    })

    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  const artboard = store.state.artboardSize
  const fitted = useMemo(() => {
    if (viewportSize.width <= 0 || viewportSize.height <= 0) {
      return { width: 0, height: 0 }
    }

    const ratio = artboard.width / artboard.height
    let width = viewportSize.width
    let height = width / ratio

    if (height > viewportSize.height) {
      height = viewportSize.height
      width = height * ratio
    }

    return {
      width: Math.max(1, Math.round(width)),
      height: Math.max(1, Math.round(height)),
    }
  }, [artboard.height, artboard.width, viewportSize.height, viewportSize.width])

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: '#141414',
      userSelect: 'none',
    }}>
      <Toolbar />

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', minHeight: 0 }}>

        {/* ── Canvas viewport ─────────────────────────────────────────────── */}
        <div style={{
          flex: 1,
          background: '#1e1e1e',
          backgroundImage: `
            radial-gradient(circle at 20% 20%, rgba(108,99,255,0.04) 0%, transparent 60%),
            radial-gradient(circle at 80% 80%, rgba(255,100,130,0.03) 0%, transparent 60%)
          `,
          overflow: 'hidden',
          padding: 28,
          position: 'relative',
        }}>
          {/* Subtle dot grid bg */}
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.04) 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }} />

          <div
            ref={viewportRef}
            style={{
              position: 'absolute',
              inset: 28,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              overflow: 'visible',
            }}
          >
            {/* Canvas wrapper */}
            <div style={{
              position: 'relative',
              borderRadius: 10,
              overflow: 'visible',
              boxShadow: '0 0 0 1px rgba(255,255,255,0.06), 0 12px 48px rgba(0,0,0,0.7)',
              width: fitted.width,
              height: fitted.height,
            }}>
              <MeshCanvas />
            </div>
          </div>
        </div>

        {/* ── Right panel ─────────────────────────────────────────────────── */}
        <RightPanel />
      </div>
    </div>
  )
}
